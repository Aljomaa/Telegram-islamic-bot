import sqlite3, random, json, os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (ApplicationBuilder, CommandHandler, MessageHandler,
                          CallbackQueryHandler, ContextTypes, filters, ConversationHandler)
from apscheduler.schedulers.asyncio import AsyncIOScheduler

TOKEN = "7009199636:AAGXGxrqTnyO8OyFZeC4KSsUhAbMBifvSLU"
ADMIN_ID = 6849903309  # ضع معرف حسابك في تلغرام هنا

# تحميل المصادر
with open("data/quran.json","r",encoding="utf-8") as f: quran = json.load(f)
with open("data/tafsir_ibn_kathir.json","r",encoding="utf-8") as f: tafsir = json.load(f)
with open("data/adhkar.json","r",encoding="utf-8") as f: adhkar = json.load(f)
with open("data/ahadith.json","r",encoding="utf-8") as f: ahadith = json.load(f)

# إعداد قاعدة البيانات
conn = sqlite3.connect("db.sqlite", check_same_thread=False)
c = conn.cursor()
c.executescript("""
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, notify_prayer INTEGER, notify_adhkar INTEGER);
CREATE TABLE IF NOT EXISTS used_ayah(user_id, sura, ayah);
CREATE TABLE IF NOT EXISTS used_adhkar(user_id, adhkar);
CREATE TABLE IF NOT EXISTS used_hadiths(user_id, hefth_id);
CREATE TABLE IF NOT EXISTS favorites(user_id, type, content);
CREATE TABLE IF NOT EXISTS complaints(user_id, text);
CREATE TABLE IF NOT EXISTS logs(time TEXT, level TEXT, message TEXT);
""")
conn.commit()

scheduler = AsyncIOScheduler()

def log(level, msg):
    from datetime import datetime
    c.execute("INSERT INTO logs VALUES(?,?,?)", (datetime.now().isoformat(), level, msg))
    conn.commit()

async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    dp = [
      [InlineKeyboardButton("📖 قرآن عشوائي", callback_data="random_ayah")],
      [InlineKeyboardButton("🔔 ذكرك اليوم", callback_data="adhkar"), InlineKeyboardButton("⚖️ زادك اليوم", callback_data="hadith")],
      [InlineKeyboardButton("🕋 مواقيت الصلاة", callback_data="prayer_times")],
      [InlineKeyboardButton("⚙️ الإعدادات", callback_data="settings"), InlineKeyboardButton("⭐ المفضلة", callback_data="favorites")],
      [InlineKeyboardButton("📝 شكوى/اقتراح", callback_data="complaint")]
    ]
    await update.message.reply_text("أهلاً بك في بوتك الإسلامي 🌸", reply_markup=InlineKeyboardMarkup(dp))
    uid = update.effective_user.id
    c.execute("INSERT OR IGNORE INTO users VALUES(?,?,?)", (uid,1,1))
    conn.commit()

async def random_ayah_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    used = c.execute("SELECT sura,ayah FROM used_ayah WHERE user_id = ?",(uid,)).fetchall()
    unused = [(s,a) for s in quran.keys() for a in quran[s].keys() if (s,a) not in used]
    if not unused:
        c.execute("DELETE FROM used_ayah WHERE user_id=?", (uid,))
        conn.commit()
        unused = [(s,a) for s in quran.keys() for a in quran[s].keys()]
    sura, ayah = random.choice(unused)
    text = quran[sura][ayah]
    taf = tafsir.get(sura, {}).get(ayah, "لا يوجد تفسير.")
    msg = f"📖 *آية من سورة {sura}:*
{text}

🧠 *تفسير ابن كثير:*
{taf}

🔎 *تطبيق عملي:*
– تأمل هذه الآية في واقعك وطبّقها في حياتك."
    keyboard = [[InlineKeyboardButton("🔊 استماع", callback_data=f"audio_{sura}_{ayah}")]]
    await update.callback_query.edit_message_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
    c.execute("INSERT INTO used_ayah VALUES(?,?,?)", (uid, sura, ayah))
    conn.commit()

async def audio_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    _, sura, ayah = update.callback_query.data.split("_")
    path = f"data/audio/{sura}-{ayah}.mp3"
    if os.path.exists(path):
        await update.callback_query.message.reply_audio(open(path, 'rb'))
    else:
        await update.callback_query.answer("الصوت غير متوفر حالياً.", show_alert=True)

async def adhkar_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    buttons = [
      [InlineKeyboardButton("☀️ أذكار الصباح", callback_data="adhkar_morning")],
      [InlineKeyboardButton("🌙 أذكار المساء", callback_data="adhkar_evening")],
      [InlineKeyboardButton("🛐 أذكار اليوم", callback_data="adhkar_daily")]
    ]
    await update.callback_query.edit_message_text("اختر نوع الذكر:", reply_markup=InlineKeyboardMarkup(buttons))

async def send_adhkar(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    typ = update.callback_query.data.split("_")[1]
    uid = update.effective_user.id
    used = c.execute("SELECT adhkar FROM used_adhkar WHERE user_id = ?", (uid,)).fetchall()
    used = set([u[0] for u in used])
    pool = [x for x in adhkar[typ] if x not in used]
    if not pool:
        c.execute("DELETE FROM used_adhkar WHERE user_id=?", (uid,))
        conn.commit()
        pool = adhkar[typ]
    selection = random.choice(pool)
    await update.callback_query.edit_message_text(f"🕋 *ذِكر {typ}:*
{selection}", parse_mode="Markdown")
    c.execute("INSERT INTO used_adhkar VALUES(?,?)", (uid, selection))
    conn.commit()

async def hadith_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.callback_query.message.chat_id
    used = c.execute("SELECT hefth_id FROM used_hadiths WHERE user_id=?", (uid,)).fetchall()
    used = set(u[0] for u in used)
    pool = [h for h in ahadith if h["id"] not in used]
    if not pool:
        c.execute("DELETE FROM used_hadiths WHERE user_id=?", (uid,))
        conn.commit()
        pool = ahadith
    h = random.choice(pool)
    msg = f"📜 *حديث شريف:*

“{h['text']}”

📚 *المصدر:* {h['source']}

🧠 *تفسير:* {h['tafsir']}

🔎 *تطبيق عملي:* {h['application']}"
    await update.callback_query.edit_message_text(msg, parse_mode="Markdown")
    c.execute("INSERT INTO used_hadiths VALUES(?,?)", (uid, h["id"]))
    conn.commit()

def main():
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(random_ayah_handler, pattern="random_ayah"))
    app.add_handler(CallbackQueryHandler(audio_handler, pattern="audio_"))
    app.add_handler(CallbackQueryHandler(adhkar_handler, pattern="adhkar$"))
    app.add_handler(CallbackQueryHandler(send_adhkar, pattern="adhkar_"))
    app.add_handler(CallbackQueryHandler(hadith_handler, pattern="hadith"))
    app.run_polling()

if __name__ == "__main__":
    main()
